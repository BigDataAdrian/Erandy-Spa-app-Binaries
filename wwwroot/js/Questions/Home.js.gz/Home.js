﻿document.addEventListener("DOMContentLoaded", () => {
    setActiveMenu("QuestionsModule", "QuestionsModuleHome");
    LoadQuestions();

    const BtnDeleteQuestion = document.getElementById('BtnDeleteQuestion');
    BtnDeleteQuestion.addEventListener('click', async () => {
        await DeleteQuestion();
    });

    const BtnCreateQuestionModal = document.getElementById('BtnCreateQuestionModal');
    BtnCreateQuestionModal.addEventListener('click', async () => {
        await CreateQuestionModalOpen();
    });

    const BtnCreateQuestion = document.getElementById('BtnCreateQuestion');
    BtnCreateQuestion.addEventListener('click', async () => {
        await AddQuestion();
    });

    const BtnUpdateQuestion = document.getElementById('BtnUpdateQuestion');
    BtnUpdateQuestion.addEventListener('click', async () => {
        await UpdateQuestion();
    });
});

async function LoadQuestions() {
    try {
        const response = await fetch(`/Questions/GetQuestions`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });

        if (response.status >= 200 && response.status <= 299) {
            const result = await response.json().catch(() => null);

            const tbody = document.querySelector("#QuestionsTable tbody");

            tbody.innerHTML = "";
            result.forEach(c => {
                const tr = document.createElement("tr");
                tr.setAttribute("data-id", c.id);
                tr.innerHTML = `
                <td>${c.question}</td>
                <td>${c.response}</td>
                <td> 
                    <div class="btn-group float-end" role="group" aria-label="Acciones">
                        <button  onclick="DeleteQuestionModalOpen(${c.id},'${c.question}')" class="btn btn-outline-danger">
                            <i class="bi bi-trash"></i>
                        </button>
                        <button onclick="UpdateQuestionModalOpen(${c.id},'${c.question}','${c.response}')" class="btn btn-outline-warning">
                            <i class="bi bi-pencil"></i>
                        </button>
                    </div>
                </td>
            `;

                tbody.appendChild(tr);

            });
        }


        if (response.status >= 400 && response.status <= 499) {
            const result = await response.text().catch(() => null);
            showToast("warning", result);
        }

        if (response.status >= 500 && response.status <= 599) {
            const result = await response.text().catch(() => null);
            showToast("danger", result);
        }

    } catch (error) {
        showToast("danger", error);
    }
}
function DeleteQuestionModalOpen(Id, Question) {
    document.getElementById("LabelModalDeleteQuestion").innerText = Question;
    sessionStorage.setItem('QuestionIdSelected', Id);
    var DeleteQuestionModal = new bootstrap.Modal(document.getElementById("DeleteQuestionModal"));
    DeleteQuestionModal.show();
}
async function DeleteQuestion() {
    try {
        var Id = sessionStorage.getItem('QuestionIdSelected');
        const data = {
            QuestionId: Id
        };
        const response = await fetch("/Questions/DeleteQuestion", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (response.status >= 200 && response.status <= 299) {
            const result = await response.text().catch(() => null);
            showToast("success", result);
            const DeleteQuestionModal = document.getElementById('DeleteQuestionModal');
            const modalInstance = bootstrap.Modal.getInstance(DeleteQuestionModal);

            if (!modalInstance) {
                new bootstrap.Modal(modalElement).hide();
            } else {
                modalInstance.hide();
            }

            LoadQuestions();
        }

        if (response.status == 400 && response.status <= 499) {
            const result = await response.text().catch(() => null);
            showToast("warning", result);
        }

        if (response.status == 500 && response.status <= 599) {
            const result = await response.text().catch(() => null);

            showToast("danger", result);
        }
    } catch (error) {
        showToast("danger", error);
    }
}
function CreateQuestionModalOpen() {
    var CreateQuestionModal = new bootstrap.Modal(document.getElementById("CreateQuestionModal"));
    CreateQuestionModal.show();
}
async function AddQuestion() {
    try {
        const Question = document.getElementById("CreateModalQuestion");
        const Response = document.getElementById("CreateModalResponse");

        const data = {
            Question: Question.value,
            Response: Response.value,
        };
        const response = await fetch("/Questions/AddQuestion", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (response.status >= 200 && response.status <= 299) {
            const result = await response.text().catch(() => null);

            document.getElementById("CreateModalQuestion").value = "";
            document.getElementById("CreateModalResponse").value = "";
            showToast("success", result);
            const CreateQuestionModal = document.getElementById('CreateQuestionModal');
            const modalInstance = bootstrap.Modal.getInstance(CreateQuestionModal);

            if (!modalInstance) {
                new bootstrap.Modal(modalElement).hide();
            } else {
                modalInstance.hide();
            }
            LoadQuestions();

        }

        if (response.status == 400 && response.status <= 499) {
            const result = await response.text().catch(() => null);
            showToast("warning", result);
        }

        if (response.status == 500 && response.status <= 599) {
            const result = await response.text().catch(() => null);

            showToast("danger", result);
        }
    } catch (error) {
        showToast("danger", error);
    }
}
async function UpdateQuestion() {
    try {
        const Id = sessionStorage.getItem('QuestionIdSelected');
        const Question = document.getElementById("UpdateModalQuestion");
        const Response = document.getElementById("UpdateModalResponse");

        const data = {
            Id: Id,
            Question: Question.value,
            Response: Response.value
        };
        const response = await fetch("/Questions/UpdateQuestion", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (response.status >= 200 && response.status <= 299) {
            const result = await response.text().catch(() => null);
            showToast("success", result);
            const UpdateQuestionModal = document.getElementById('UpdateQuestionModal');
            const modalInstance = bootstrap.Modal.getInstance(UpdateQuestionModal);

            if (!modalInstance) {
                new bootstrap.Modal(modalElement).hide();
            } else {
                modalInstance.hide();
            }
            LoadQuestions();

        }

        if (response.status == 400 && response.status <= 499) {
            const result = await response.text().catch(() => null);
            showToast("warning", result);
        }

        if (response.status == 500 && response.status <= 599) {
            const result = await response.text().catch(() => null);

            showToast("danger", result);
        }
    } catch (error) {
        showToast("danger", error);
    }
}
function UpdateQuestionModalOpen(Id, Question, Response, Intention, Module) {

    sessionStorage.setItem('QuestionIdSelected', Id);
    document.getElementById("UpdateModalQuestion").value = Question;
    document.getElementById("UpdateModalResponse").value = Response;

    var UpdateQuestionModal = new bootstrap.Modal(document.getElementById("UpdateQuestionModal"));
    UpdateQuestionModal.show();
}